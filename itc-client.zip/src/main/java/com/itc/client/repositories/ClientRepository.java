package com.itc.client.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.itc.client.entities.Client;

@Repository
public interface ClientRepository extends CrudRepository<Client, Long> {
    
    List<Client> findByFirstname(String firstname);
    
    Client findByClientid(String clientid);
    
    Client findByMobilenumber(String mobileno);
    
    List<Client> findByFirstnameOrClientidOrMobilenumber(String firstname,String clientid,String mobileno);
    
    List<Client> findByFirstnameAndClientidAndMobilenumber(String firstname,String clientid,String mobileno);
    
}
