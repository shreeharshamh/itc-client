package com.itc.client.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity

public class Client {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
   
    @NotBlank(message = "firstName is required")
    private String firstname;    
    
    @NotBlank(message = "lastName is required")
    private String lastname;

    @NotBlank(message = "clientId is required")
    private String clientid;    
   
    private String physicaladdress;
    
    private String mobilenumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getPhysicaladdress() {
		return physicaladdress;
	}

	public void setPhysicaladdress(String physicaladdress) {
		this.physicaladdress = physicaladdress;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	@Override
	public String toString() {
		return "Client [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", clientid=" + clientid
				+ ", physicaladdress=" + physicaladdress + ", mobilenumber=" + mobilenumber + "]";
	}

	public Client(@NotBlank(message = "firstName is required") String firstname,
			@NotBlank(message = "lastName is required") String lastname,
			@NotBlank(message = "clientId is required") String clientid, String physicaladdress, String mobilenumber) {
		super();		
		this.firstname = firstname;
		this.lastname = lastname;
		this.clientid = clientid;
		this.physicaladdress = physicaladdress;
		this.mobilenumber = mobilenumber;
	}
    
    

	
	 public Client() {}
   

}
