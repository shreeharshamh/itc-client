package com.itc.client.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.itc.client.entities.Client;
import com.itc.client.repositories.ClientRepository;
import com.itc.client.util.ClientUtil;

@Controller
public class ClientController {

	private final ClientRepository clientRepository;

	@Autowired
	public ClientController(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}


	@GetMapping("/search")
	public String findAll(Client client,BindingResult result, Model model) {
		System.out.println("searchField----"+client);

		
		//model.addAttribute("clients", clientRepository.findByFirstnameAndClientidAndMobilenumber(client.getFirstname(),client.getClientid(),client.getMobilenumber()));
		model.addAttribute("clients", clientRepository.findByFirstnameOrClientidOrMobilenumber(client.getFirstname(),client.getClientid(),client.getMobilenumber()));
		client=new Client();
		return "index"; 
	}


	@GetMapping("/")
	public String index(Client client, Model model) {
		System.out.println("index----");


		//model.addAttribute("clients", clientRepository.findByFirstnameAndClientidAndMobilenumber(client.getFirstname(),client.getClientid(),client.getMobilenumber()));
		model.addAttribute("clients", clientRepository.findAll());
		return "index"; 
	}

	
	
	@GetMapping("/new")
	public String showSignUpForm(Client client,Model model) {
		model.addAttribute("clients", clientRepository.findAll());
		return "add-client";
	}


	@GetMapping("/edit/{id}")
	public String showUpdateForm(@PathVariable("id") long id, Model model) {
		Client client = clientRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid client Id:" + id));
		model.addAttribute("client", client);
		return "update-client";
	}

	@GetMapping("/delete/{id}")
	public String deleteUser(@PathVariable("id") long id, Model model) {
		Client client = clientRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid client Id:" + id));
		clientRepository.delete(client);
		model.addAttribute("clients", clientRepository.findAll());
		return "index";
	}

	@PostMapping("/addclient")
	public String addUser(@Valid Client client, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("errorMessage", "Errors");
			return "add-client";
		}

		boolean isValidZaId =	ClientUtil.isValidIdNumber(client.getClientid());
		Client clientDup =	clientRepository.findByClientid(client.getClientid());
		Client clientDupMobileNo =	clientRepository.findByMobilenumber(client.getMobilenumber());


		//	boolean idDuplicateClientId =	ClientUtil.checkForDuplicateClientId(client.getMobilenumber());
		//	boolean idDuplicateMobileNo =	ClientUtil.checkForDuplicateMobileNumber(client.getMobilenumber());

		if(!isValidZaId) {
			model.addAttribute("errorMessage", "Invalid South african Id");
			return "add-client";			
		}

		if(clientDup!=null  && clientDupMobileNo!=null) {
			model.addAttribute("errorMessage", "Duplicate South african Id & Duplicate Mobile Number");
			return "add-client";
		}

		if(clientDup!=null  ) {
			model.addAttribute("errorMessage", "Duplicate South african Id");
			return "add-client";
		}

		if(clientDupMobileNo!=null) {
			model.addAttribute("errorMessage", "Duplicate Mobile Number");
			return "add-client";
		}


		clientRepository.save(client);
		//List<Client> clientInDB = clientRepository.findByFirstname(client.getFirstname());
		//System.out.println("---clientInDB--"+clientInDB);
		model.addAttribute("clients", clientRepository.findAll());

		return "index";
	}

	@PostMapping("/update/{id}")
	public String updateUser(@PathVariable("id") long id, @Valid Client client, BindingResult result, Model model) {
		if (result.hasErrors()) {
			client.setId(id);
			return "update-client";
		}

		boolean isValidZaId =	ClientUtil.isValidIdNumber(client.getClientid());
		Client clientDup =	clientRepository.findByClientid(client.getClientid());
		Client clientDupMobileNo =	clientRepository.findByMobilenumber(client.getMobilenumber());


		//	boolean idDuplicateClientId =	ClientUtil.checkForDuplicateClientId(client.getMobilenumber());
		//	boolean idDuplicateMobileNo =	ClientUtil.checkForDuplicateMobileNumber(client.getMobilenumber());

		if(!isValidZaId) {
			model.addAttribute("errorMessage", "Invalid South african Id");
			return "update-client";			
		}

		if(clientDup!=null  && clientDupMobileNo!=null) {
			model.addAttribute("errorMessage", "Duplicate South african Id & Duplicate Mobile Number");
			return "update-client";
		}

		if(clientDup!=null  ) {
			model.addAttribute("errorMessage", "Duplicate South african Id");
			return "update-client";
		}

		if(clientDupMobileNo!=null) {
			model.addAttribute("errorMessage", "Duplicate Mobile Number");
			return "update-client";
		}
		
		clientRepository.save(client);
		model.addAttribute("clients", clientRepository.findAll());
		return "index";
	}


}
